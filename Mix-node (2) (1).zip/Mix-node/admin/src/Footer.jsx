function Footer(){
return(
<footer className="footer mt-auto py-3 bg-white text-center">
                <div className="container">
                    <span className="text-muted"> Copyright © <span id="year"></span> <a
                            href="javascript:void(0);" className="text-dark fw-semibold">AgroFARM.</a>  
                          All
                        rights
                        reserved
                    </span>
                </div>
            </footer>
);
}

export default Footer;