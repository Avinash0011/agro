import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import React from 'react';

function Header({mobile,banda}){
  


 return(
    
<header className="app-header">


<div className="main-header-container container-fluid">

    
    <div className="header-content-left">

       
      
    </div>
    {/* End::header-content-left */}

</div>
{/* End::main-header-container */}

</header>  

);
}
export default Header;