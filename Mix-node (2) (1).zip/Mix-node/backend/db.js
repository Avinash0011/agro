const mongodb=require("mongodb");

mongodb.connect("mongodb://localhost:27017");